# DiDal ☁️

A **Kerbal Space Program 1** mod that aims to add beautiful clouds to Kerbin.

## 🌍 About

DiDal is a fan-made visual mod for Kerbal Space Program 1.

The goal of DiDal is to make Kerbin look more realistic and beautiful by adding clouds to its atmosphere.

## ✨ Features

- ☁️ Clouds for Kerbin
- 🌍 Improved visual atmosphere
- 🚀 Designed for Kerbal Space Program 1

## 📦 Installation

1. Download the latest DiDal release.
2. Open the downloaded ZIP file.
3. Extract the `GameData` folder into your KSP installation folder.
4. Start Kerbal Space Program 1.

## ⚙️ Requirements

- Kerbal Space Program 1
- EnvironmentalVisualEnhancements (EVE), if required by a future version

## 🚧 Development Status

DiDal is currently in **early development**.

More features and improvements will be added in future updates.

## 📜 License

DiDal is licensed under the MIT License.

See `LICENCE.txt` for more information.

## ❤️ Credits

Created by **clouds-123-droid**.

Made with love for the Kerbal Space Program community! 🚀